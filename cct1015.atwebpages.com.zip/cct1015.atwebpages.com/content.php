<?php
     //Start Session
     //session_start();

     //Create constants to store non repeat values
     define('SITEURL','http://party.haochang.tv/share/rooms?roomCode=');
     define('APPURL','chunkyuechang://v1.chunkyuechang.com?eyJ1cmwiOiJyb29tIiwidGFyZ2V0IjoiYXBwIiwiZGF0YSI6eyJyb29tQ29kZSI6Ij');
     define('LOCALHOST','fdb32.awardspace.net');
     define('DB_USERNAME','4020537_party');
     define('DB_PASSWORD','421424wizard');
     define('DB_NAME','4020537_party');

     $conn=mysqli_connect(LOCALHOST,DB_USERNAME,DB_PASSWORD) or die(mysqli_error());     //connection database
     $db_select=mysqli_select_db($conn,DB_NAME) or die(mysqli_error());        //selectiong database
     
     

?>