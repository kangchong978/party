<?php include('content.php');?>
<!DOCTYPE html>
<link rel="stylesheet" href="style_new.css?0.12"/>
<head>
    <title>猪头表</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<html>
    <body>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script>
            $(document).scroll(function() {
                var y = $(this).scrollTop();
                if (y > 240) {
                    $('.go-top').fadeIn();
                    document.getElementById("container_h").style.background = "#00204a";
                    document.getElementById("container_h").style.borderRadius = "0px 0px 20px 20px";
                    document.getElementById("container_h").style.paddingTop = "10px";
                } else {
                    $('.go-top').fadeOut();
                    document.getElementById("container_h").style.background = "rgba(255, 255, 255, 0.048)";
                    document.getElementById("container_h").style.borderRadius = "15px";
                    document.getElementById("container_h").style.paddingTop = "0px";
                }
                });
                
        </script>
        <script>
            $(() => {
                const stuckClass = 'is-stuck';
                const $stickyTopElements = $('.tag');
                
                const determineSticky = () => {
                    $stickyTopElements.each((i, el) => {
                    const $el = $(el);
                    const stickPoint = parseInt($el.css('top'), 10);
                    const currTop = el.getBoundingClientRect().top;
                    const isStuck = currTop <= stickPoint;
                    $el.toggleClass(stuckClass, isStuck);
                    });
                };

                //run immediately
                determineSticky();

                //Run when the browser is resized or scrolled
                //Uncomment below to run less frequently with a debounce
                //let debounce = null;
                $(window).on('resize scroll', () => {
                    //clearTimeout(debounce);
                    //debounce = setTimeout(determineSticky, 100);

                    determineSticky();
                });

            });
        </script>

        <div class="go-top" onclick="location.href='#section#header';"></div>
        <div id="section#header" class="container" style="padding:0px;height:200px;"><table><tr><h1 style="font-size:60px;letter-spacing: 1px;"><?php include('Clock.php') ?></h1></tr><tr>
            <?php
            $showlatestupdateSQL="SELECT * FROM latestupdate ORDER BY id DESC LIMIT 1;";
            $res1= mysqli_query($conn,$showlatestupdateSQL);
            $rows1=mysqli_fetch_assoc($res1);
            $latestdate=$rows1['time'];
            ?>
            <p onclick="location.href='./sql.php';" style="font-size:14px;text-align:center;">Latest Update: <?php echo $latestdate;?></p></tr></table></div><br>
        <div id="container_h" class="container_h" style="padding-left:20px;padding-right:20px;border-radius: 20px;">
            <div style="padding:1px;overflow-y: scroll;">
                <table class="timeschedule" style="margin: auto;table-layout:auto;width:100%;">
                <?php
                $sql_H="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC";
                $res_H = mysqli_query($conn,$sql_H);
                $count_H = mysqli_num_rows($res_H);
                $previous_H='';
                if($res_H==TRUE){
                    if($count_H>0){
                        ?>
                    <tr>
                        <td><td><a href="#section#home" class="glass-button-time"><?php echo "🏠";?></a></td>
                        <td><td><a href="#section#00:00" class="glass-button-time"><?php echo "00:00";?></a></td>
                        <td><td><a href="#section#08:00" class="glass-button-time"><?php echo "08:00";?></a></td>
                        <td><td><a href="#section#11:00" class="glass-button-time"><?php echo "11:00";?></a></td>
                        <td><td><a href="#section#13:00" class="glass-button-time"><?php echo "13:00";?></a></td>
                        <td><td><a href="#section#14:00" class="glass-button-time"><?php echo "14:00";?></a></td>
                        <td><td><a href="#section#16:00" class="glass-button-time"><?php echo "16:00";?></a></td>
                        <td><td><a href="#section#18:00" class="glass-button-time"><?php echo "18:00";?></a></td>
                        <td><td><a href="#section#20:00" class="glass-button-time"><?php echo "20:00";?></a></td>
                        <td><td><a href="#section#21:00" class="glass-button-time"><?php echo "21:00";?></a></td>
                        <td><td><a href="#section#22:00" class="glass-button-time"><?php echo "22:00";?></a></td>
                    </tr>
                    <?php

                    }
                }
            ?>
                </table>
            </div>
        </div>
        <br>
        
        <?php
        //query to get all admin
            

            $sql="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC;";
            //execute the query
            $res = mysqli_query($conn,$sql);
            //count rows to check whether we have data in database or not
            $count = mysqli_num_rows($res);//function to get all the rows in databse
            
            $previous='';
            if($res==TRUE){
                
                //check the num of rows
                if($count>0){
                    //we have data in database
                    while($rows=mysqli_fetch_assoc($res)){
                        //Using while loop to get all the data from database
                        //and while loop will run as long as we have data in database
                        //get individual data
                        
                        $time=$rows['time'];
                        
                        if ($time != $previous) {
                     
                                    ?>
                                            <br id="section#<?php echo $time;?>">
                                            <br>
                                            <div class="container">
                                            <div class="container-tag"><div id="tag" class="tag"><?php echo $time;?></div></div>
                                            <div style="height:70px;width:100%;"></div>
                                            
                                            <br>
                                            <!-- <h1 style="font-size:20px;" id="section#<?php echo $time;?>"><?php echo $time; ?></h1> -->
                                            <div style="margin-top:10px;min-height:50px;overflow-y: scroll;padding:0px 20px 10px 20px;">
                                                <table style="margin: auto;table-layout:auto;width:100%;">
                                            
                                    <?php
                                    $sql_d="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC;";
                                    //execute the query
                                    $res_d = mysqli_query($conn,$sql_d);
                                    while($rows_d=mysqli_fetch_assoc($res_d)){
                                    
                                    $id_d=$rows_d['id'];
                                    $roomid_d=$rows_d['roomid'];
                                    $url=$rows_d['url'];
                                    $time_d=$rows_d['time'];
                               
                                            if($time_d==$time){
                                            ?>
                                                    <tr>
                                                        <td>
                                                             <a class="glass-button" style="width:80%;height:25px;font-size:20px;text-align: center;font-weight: bolder ;" href="<?php echo APPURL; echo $url;?>" target="_blank"><?php echo $roomid_d?></a>
                                                        </td>
                                                    </tr>
                                            <?php
                                            }
                                     }
                                    
                        ?></table></div></div><br><br><hr><?php
                        
                        }
                        
            $previous=$time;
            //display the values in table
        
                }
            }
            else{
            //do not have data in database
            ?>
            <div>
                <table>
                    <tr>
                        <td>
                            <p>
                                暂无数据
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            <?php
                }
            }
            
        ?>
        
        <br><br>
        <div class="container">
                <h1 style="font-size:20px;" id="section#home">🥐的家🏠</h1>
                <div style="padding:0px 10px 10px 10px;">
                        <table class="timeschedule" style="margin: auto;table-layout:auto;width:100%;">
                                <tr>
                                       <td>
                                               <a class="glass-button-home" style="width:50%;" href="<?php echo SITEURL; echo 123321;?>" target="_blank">🐽🐖<?php echo 123321 ?></a>
                                       </td>
                                       <td>
                                               <a class="glass-button-home" style="width:50%;" href="<?php echo SITEURL; echo 2404417;?>" target="_blank"><?php echo 2404417 ?>💖</a>
                                       </td>
                                </tr>
                                <tr>
                                       <td>
                                               <a class="glass-button-home" style="width:50%;" href="<?php echo SITEURL; echo 3024803;?>" target="_blank">🥺<?php echo 3024803 ?></a>
                                       </td>
                                       <td>
                                               <a class="glass-button-home" style="width:50%;" href="<?php echo SITEURL; echo 3491275;?>" target="_blank"><?php echo 3491275 ?>👀</a>
                                       </td>
                                </tr>
                                <tr>
                                       <td>
                                               <a class="glass-button-home" style="width:50%;" href="<?php echo SITEURL; echo 3034666;?>" target="_blank">🥺<?php echo 3034666 ?></a>
                                       </td>
                                       <td>
                                              
                                       </td>
                                </tr>
                        </table>
                </div>
        </div>
        
        <br>
    </body>
</html>