<link rel="stylesheet" href="style.css?v=0.2" />
<?php include('content.php');?>

<?php
            
    function function_alert($message) {
        echo "<script>prompt('$message');</script>";// Display the alert box 
    }


    if(isset($_SESSION['add'])){    //checking wheter the session is set or not
        function_alert($_SESSION['add']);//Display session message
        unset($_SESSION['add']);    //remove session message
    }

    if(isset($_SESSION['clear'])){    //checking wheter the session is set or not
        function_alert($_SESSION['clear']);//Display session message
        unset($_SESSION['clear']);    //remove session message
    }
?>

<head>
    <title>SQL后台</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <div>
        <table>
            <tr>
                <td class="tab"  colspan=3>
                <button class="tablinks " onclick="location.href='index.php';">首页</button>
                <button type="button" class="tablinks" onclick="location.href='admin.php';">管理</button>
                <button type="button" class="tablinks active" onclick="location.href='SQL.php';">SQL页面</button>
                </td>
            </tr>
            <tr>
                <td><h1>🎉入门猪头🐖房间🎉</h1></td>
                <td class=td-clock><?php include('Clock.php');?></td>
            </tr>    
        </table>
    </div>
    <div class=announce>
        <table class=announce-tb>
            <tr class=announce-tr>
                <td class=announce-td-icon><p>🔊</p></td>
                <td class=announce-td>
                <marquee behavior="behavior" width="auto" loop="0">愉快拿猪头🐷</marquee>
                </td>
            </tr>
        </table>
    </div>
    <div><?php
        $showlatestupdateSQL="SELECT * FROM latestupdate ORDER BY id DESC LIMIT 1;";
        $res1= mysqli_query($conn,$showlatestupdateSQL);
        $rows1=mysqli_fetch_assoc($res1);
        $latestdate=$rows1['time'];
        ?><p>更新日期：<?php echo $latestdate;?></p>
    </div>
    <div>
    <form action="" method="POST">
        <table>
            <tr>
            <td>
                <iframe src="https://docs.google.com/spreadsheets/d/1_hBqg32YRQjYvuCaCrgOW6lcLhax4DmO/edit?usp=sharing&ouid=108757387115328746053&rtpof=true&sd=true"></iframe>  
            </td>
            <td><textarea name="sqlcommands" id="sqlcommands" placeholder="
1.从Party通知->猪头表截图
2.截图丢入OCR->拿到时间和房号
3.放入左边Google Sheet里->复制前两行
4.粘贴在这里
5.提交
**Enter the SQL commands at here, Example:INSERT INTO `partyroom` (`id`, `time`, `roomid`) VALUES (NULL,'00:00','123321');"></textarea></td>
            </tr>
            <tr>
            <td colspan=2><input type="submit" class="button-1" name="submit" value="提交"></td>
            </tr>
            <tr>
            <td colspan=2><input type="submit" class="button-1" name="submit2" value="清除全部"></td>
            </tr>
            <?php
                date_default_timezone_set("Asia/Kuala_Lumpur");
                $latest_date=date("jS \of F Y h:i A");
                $latest_updateSQL="INSERT INTO latestupdate(id,time)VALUES(NULL,'".$latest_date."');";
                $clear_latestSQL="TRUNCATE TABLE latestupdate;";

                if(isset($_POST['submit2'])){
                    $sql="DELETE FROM partyroom;";
                    
                    $res=mysqli_query($conn,$sql) or die(mysqli_error());

                    if($res==TRUE){
                        $res_1=mysqli_query($conn,$clear_latestSQL) or die(mysqli_error());
                        $res_2=mysqli_query($conn,$latest_updateSQL) or die(mysqli_error());
                        //echo "Data inserted";
                        //create a session variable to display massage
                        $_SESSION['clear']="All Room Cleared Successfully";
                        //redirect page;
                        //header("location:");
                    }
                    else{
                        //echo "Failed to insert data";
                        //create a session variable to display massage
                        $_SESSION['clear']="Failed to Clear Room";
                        //redirect page;
                        //header("location:");
                    }
                }
               
                if(isset($_POST['submit'])){
                    
                    $sqlcommands=$_POST['sqlcommands'];

                    //echo $sqlcommands;

                    $sql=$sqlcommands.";";


                    $res=mysqli_query($conn,$sql) or die(mysqli_error());

                    if($res==TRUE){
                        $res_1=mysqli_query($conn,$clear_latestSQL) or die(mysqli_error());
                        $res_2=mysqli_query($conn,$latest_updateSQL) or die(mysqli_error());
                        //echo "Data inserted";
                        //create a session variable to display massage
                        $_SESSION['add']="SQL Command Run Successfully";
                        //redirect page;
                        ?><script type="text/javascript">location.href = 'SQL.php';</script><?php

                    }
                    else{
                        //echo "Failed to insert data";
                        //create a session variable to display massage
                        $_SESSION['add']="Failed to Run SQL Command";
                        //redirect page;
                        ?><script type="text/javascript">location.href = 'SQL.php';</script><?php
                    }
                }
            
                
                
            ?>
            
        </table>
    </div>
</body>