<?php include('content.php');?>
<link rel="stylesheet" href="style.css?v=0.223" />
<head>
    <title>猪头表2.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>



<body >
    <div>
        <table>
            <tr>
                <td class="tab"  colspan=3>
                <button class="tablinks active" onclick="location.href='index.php';">首页</button>
                <button type="button" class="tablinks" onclick="location.href='admin.php';">管理</button>
                <button type="button" class="tablinks" onclick="location.href='SQL.php';">SQL页面</button>
            </td>
            </tr>
            <tr>
                <td><h1>🎉入门猪头🐖房间🎉</h1></td>
                <td class=td-clock><?php include('Clock.php');?></td>
                
            </tr>    
        </table>
    </div>
    <div class=announce>
        <table class=announce-tb>
            <tr class=announce-tr>
                <td class=announce-td-icon><p>🔊</p></td>
                <td class=announce-td>
                <marquee behavior="behavior" width="auto" loop="0">愉快拿猪头🐷</marquee>
                </td>
            </tr>
        </table>
    </div>
    <div><?php
        $showlatestupdateSQL="SELECT * FROM latestupdate ORDER BY id DESC LIMIT 1;";
        $res1= mysqli_query($conn,$showlatestupdateSQL);
        $rows1=mysqli_fetch_assoc($res1);
        $latestdate=$rows1['time'];
        ?><p>更新日期：<?php echo $latestdate;?></p>
    </div>
    <?php include('room list.php');?>
    
    <br><br><br>

    
</body>