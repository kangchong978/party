
<div >
<table>
        
            <?php
                $sql_H="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC";
                $res_H = mysqli_query($conn,$sql_H);
                $count_H = mysqli_num_rows($res_H);
                $previous_H='';
                if($res_H==TRUE){
                    if($count_H>0){
                        ?>
                        <th colspan=5>目录</th>
                        <tr><td class="td-H"><a href="#section#00:00"><?php echo "00:00";?></a></td>
                        <td class="td-H"><a href="#section#08:00"><?php echo "08:00";?></a></td>
                        <td class="td-H"><a href="#section#11:00"><?php echo "11:00";?></a></td>
                        <td class="td-H"><a href="#section#13:00"><?php echo "13:00";?></a></td>
                        <td class="td-H"><a href="#section#14:00"><?php echo "14:00";?></a></td>
                        
                        
                        <tr><td class="td-H"><a href="#section#16:00"><?php echo "16:00";?></a></td>
                        <td class="td-H"><a href="#section#18:00"><?php echo "18:00";?></a></td>
                        <td class="td-H"><a href="#section#20:00"><?php echo "20:00";?></a></td>
                        <td class="td-H"><a href="#section#21:00"><?php echo "21:00";?></a></td>
                        <td class="td-H"><a href="#section#22:00"><?php echo "22:00";?></a></td></tr>
                        <?php

                    }
                }
            ?>
        
    </table>
    <br>
    <table>
        <tr>
        <?php
        //query to get all admin
            

            $sql="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC;";
            //execute the query
            $res = mysqli_query($conn,$sql);
            //count rows to check whether we have data in database or not
            $count = mysqli_num_rows($res);//function to get all the rows in databse
            $sn = 1;//create  a variable and assign value
            $previous='';
            if($res==TRUE){
                
                //check the num of rows
                if($count>0){
                    //we have data in database
                    while($rows=mysqli_fetch_assoc($res)){
                        //Using while loop to get all the data from database
                        //and while loop will run as long as we have data in database
                        //get individual data
                        $id=$rows['id'];
                        $time=$rows['time'];
                        $roomid=$rows['roomid'];
                        if ($time != $previous) {
                            $sn=1;
        ?>
        <tr>
            <th class='td-space' colspan=5 id="section#<?php echo $time;?>"><?php echo $time; ?></th>
        </tr>
        <?php
            }
            $previous=$time;
            //display the values in table
        ?>
        <tr>
        <td class="td-rw">
            <?php echo $sn++; ?>
        </td>
            <td class="td-rw"><?php echo $time; ?></td>
            <td class="td-rw"><?php echo $roomid; ?></td>
            <td class="td-rw-bt"><a class="button-1"  href="<?php echo SITEURL; echo $roomid; echo "#";echo $id?>" target="_blank">进入房间</a></td>       
            
        </tr>
        <?php
                }
            }
            else{
            //do not have data in database
            ?>
            <div>
                <table>
                    <tr>
                        <td>
                            <p>
                                暂无数据
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
            <?php
                }
            }
        ?>
    </table>
    
</div>

