


<?php include('content.php');?>
<link rel="stylesheet" href="style.css?v=0.2223" />
<?php
            
    function function_alert($message) {
        echo "<script>prompt('$message');</script>";// Display the alert box 
    }


    if(isset($_SESSION['add'])){    //checking wheter the session is set or not
        function_alert($_SESSION['add']);//Display session message
        unset($_SESSION['add']);    //remove session message
    }
    if(isset($_SESSION['delete'])){    //checking wheter the session is set or not
        function_alert($_SESSION['delete']);//Display session message
        unset($_SESSION['delete']);    //remove session message
    }
    

?>

<head>
    <title>猪头表2.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body >
    <div>
        <table>
            <tr>
                <td class="tab"  colspan=3>
                <button type="button" class="tablinks" onclick="location.href='index.php';">首页</button>
                <button type="button" class="tablinks active" onclick="location.href='admin.php';">管理</button>
                <button type="button" class="tablinks" onclick="location.href='SQL.php';">SQL页面</button>
                </td>
            </tr>
            <tr>
                <td><h1>🎉入门猪头🐖房间🎉</h1></td>
                <td class=td-clock><?php include('Clock.php');?></td>
            </tr>    
        </table>
    </div>
    <div class=announce>
        <table class=announce-tb>
            <tr class=announce-tr>
                <td class=announce-td-icon><p>🔊</p></td>
                <td class=announce-td>
                <marquee behavior="behavior" width="auto" loop="0">愉快拿猪头🐷</marquee>
                </td>
            </tr>
        </table>
    </div>
    <div><?php
        $showlatestupdateSQL="SELECT * FROM latestupdate ORDER BY id DESC LIMIT 1;";
        $res1= mysqli_query($conn,$showlatestupdateSQL);
        $rows1=mysqli_fetch_assoc($res1);
        $latestdate=$rows1['time'];
        ?><p>更新日期：<?php echo $latestdate;?></p>
    </div>
<div >
    <table>
            <!---
        <?php
                $sql_A="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC";
                $res_A = mysqli_query($conn,$sql_A);
                $count_A = mysqli_num_rows($res_A);
                $previous_A='';
                if($res_A==TRUE){
                    if($count_A>0){
                        while($rows_A=mysqli_fetch_assoc($res_A)){
                            $time_A=$rows_A['time'];
                            if($time_A!=$previous_A){
                                
                                ?>
                                <tr>
                                    <td class="td-H"><a href="#section#A#<?php echo $time_A;?>">ㅤㅤㅤㅤㅤㅤㅤㅤㅤ<?php echo $time_A;?>ㅤㅤㅤㅤㅤㅤㅤㅤㅤ</a></td>
                                </tr>
                                <?php
                            }
                            $previous_A=$time_A;
                        }
                    }
                }
            ?>
    </table>
    <br>--->
    <?php include('addroom.php');?>
    
    <table>
        <tr>
        <?php
                //query to get all admin
                $sql="SELECT * FROM partyroom ORDER BY `partyroom`.`time` ASC";
                //execute the query
                $res = mysqli_query($conn,$sql);
                if($res==TRUE){
                //count rows to check whether we have data in database or not
                $count = mysqli_num_rows($res);//function to get all the rows in databse
                            
                $sn = 1;//create  a variable and assign value
                $previous='';
                //check the num of rows
                if($count>0){
                //we have data in database
                    
                    while($rows=mysqli_fetch_assoc($res)){
                    //Using while loop to get all the data from database
                    //and while loop will run as long as we have data in database
                    //get individual data
                        $id=$rows['id'];
                        $time=$rows['time'];
                        $roomid=$rows['roomid'];
                        if ($time != $previous) {
                            $sn=1;
            ?>
                <tr>
                    <th class='td-space' colspan=5 id="section#A#<?php echo $time;?>"><?php echo $time; ?></th>
                </tr>
                        <tr>
                            <th>No.</th>
                            <th>时间.</th>
                            <th colspan=3>房号</th>
                        </tr>
            <?php
                        }
                        $previous=$time;
                        
                        //display the values in table
                        
                        
            ?>
                            
                        <tr>
                            <td><?php echo $sn++; ?></td>
                            <td class="td-rw"><?php echo $time; ?></td>
                            <td class="td-rw"><?php echo $roomid; ?></td>
                            <form action="" method="POST">
                            <td class="td-rw-bt"><button type="button" class="button-1" onclick="window.location.href='deleteroom.php?id=<?php echo $id;?>'">删除</button></td>
                            </form>
                        </tr>
                            
            <?php
                            
                    }
                }
                else{
                //do not have data in database
                ?>
                <div>
                    <table>
                        <tr>
                            <td>
                                <p>
                                    暂无数据
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php
                    }
                }
            ?>
        </tr>
    </table>
</div>

