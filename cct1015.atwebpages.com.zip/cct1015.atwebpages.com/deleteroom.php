
<?php include('content.php');?>
<?php
date_default_timezone_set("Asia/Kuala_Lumpur");
$latest_date=date("jS \of F Y h:i A");
$latest_updateSQL="INSERT INTO latestupdate(id,time)VALUES(NULL,'".$latest_date."');";
$clear_latestSQL="TRUNCATE TABLE latestupdate;";
    //1. get the id of admin to be deleted
    echo $id=$_GET['id'];

    //2. create sql query to delete admin
    $sql = "DELETE FROM partyroom WHERE id=$id";

    //execute the query
    $res = mysqli_query($conn, $sql);

    //check whether the query executed successfullt or not
    if($res==TRUE){
        $res_1=mysqli_query($conn,$clear_latestSQL) or die(mysqli_error());
        $res_2=mysqli_query($conn,$latest_updateSQL) or die(mysqli_error());
        //query executed successfully and admin deleted
        //echo "Admin deleted";
        //create session variable to display massage
        $_SESSION['delete']="Room Deleted Successfully";
        //redirect to manage admin page
        ?><script type="text/javascript">location.href = 'admin.php';</script><?php

    }
    else{
        //failed to delete admin
        //echo "Admin delete failed";
        $_SESSION['delete']="Room Deleted Failure";
        //redirect to manage admin page
        ?><script type="text/javascript">location.href = 'admin.php';</script><?php
    }


    //redirect to manage admin page with message(success/error)


?>