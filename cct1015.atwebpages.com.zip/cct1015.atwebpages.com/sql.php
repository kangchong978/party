<?php include('content.php');?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <body>
    <?php
            
            function function_alert($message) {
                echo "<script>prompt('$message');</script>";// Display the alert box 
            }
        
        
            if(isset($_SESSION['add'])){    //checking wheter the session is set or not
                function_alert($_SESSION['add']);//Display session message
                unset($_SESSION['add']);    //remove session message
            }
        
            if(isset($_SESSION['clear'])){    //checking wheter the session is set or not
                function_alert($_SESSION['clear']);//Display session message
                unset($_SESSION['clear']);    //remove session message
            }
        ?>
        <div>
            <a href="http://cct1015.atwebpages.com/" target="_blank">👈Home</a>
            <a href="https://www.onlineocr.net/" target="_blank">OCR</a>
            <a href="https://docs.google.com/spreadsheets/d/1_hBqg32YRQjYvuCaCrgOW6lcLhax4DmO/edit?usp=sharing&ouid=108757387115328746053&rtpof=true&sd=true" target="_blank">GoogleSheets</a>
        </div> 
        <form action="" method="POST">
            <div style="padding-top:10px;" style="width:100%;height:50%;"><textarea style="width:100%;height:50%;resize: vertical;" name="sqlcommands" id="sqlcommands" placeholder="
                1.从Party通知->猪头表截图
                2.截图丢入OCR->拿到时间和房号
                3.放入左边Google Sheet里->复制前两行
                4.粘贴在这里
                5.提交
                **Enter the SQL commands at here, Example:INSERT INTO `partyroom` (`id`, `time`, `roomid`,`url`) VALUES (NULL,'00:00','123321','123321ABCD');"></textarea></div>
            </div>
            <div style="width:100%;padding-top:10px;"><div style="position:related;"><input type="submit" style="width:100%;height:50px;" name="submit" value="提交"></input></div></div>
        </form>
    </body>
</html>
<?php
    date_default_timezone_set("Asia/Kuala_Lumpur");
    $latest_date=date("jS \of F Y h:i A");
    $latest_updateSQL="INSERT INTO latestupdate(id,time)VALUES(NULL,'".$latest_date."');";
    $clear_latestSQL="TRUNCATE TABLE latestupdate;";

    if(isset($_POST['submit'])){
        $sqlcommands=$_POST['sqlcommands'];
        $sql_import=$sqlcommands.";";
        $sql="TRUNCATE TABLE partyroom;";
        $res=mysqli_query($conn,$sql) or die(mysqli_error());

        if($res==TRUE){
            $res_import=mysqli_query($conn,$sql_import) or die(mysqli_error());
            $res_1=mysqli_query($conn,$clear_latestSQL) or die(mysqli_error());
            $res_2=mysqli_query($conn,$latest_updateSQL) or die(mysqli_error());
            //echo "Data inserted";
            //create a session variable to display massage
            $_SESSION['add']="SQL Command Run Successfully";
            //redirect page;
            //header("location:");
        }else{
            //echo "Failed to insert data";
            //create a session variable to display massage
            $_SESSION['add']="Failed to Run SQL Command";
            //redirect page;
            //header("location:");
        }
    }
?>